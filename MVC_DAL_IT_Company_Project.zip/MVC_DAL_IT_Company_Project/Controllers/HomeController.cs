﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using MVC_DAL_IT_Company_Project.Models;

namespace MVC_DAL_IT_Company_Project.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            ViewBag.msg = "Employee Details";
            return View();
        }
        public ActionResult AddEmployee()
        {
            Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
            ViewBag.dept = dal.GetEmployeeDept();
            ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
            ViewBag.status = dal.GetProjectAllocationStatus();
            return View();
        }
        [HttpPost]

        public ActionResult AddEmployee(EmployeeModel model)
        {
            try
            {
                if (ModelState.IsValid)
                {
                    model.EmployeeImage = "/Images/" + Guid.NewGuid() + ".jpg";
                    model.EmployeeImageFile.SaveAs(Server.MapPath(model.EmployeeImage));
                    Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                    int id = dal.AddEmployee(model);
                    ViewBag.msg = "Employee Added : " + id;
                    ModelState.Clear();
                    ViewBag.dept = dal.GetEmployeeDept();
                    ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
                    ViewBag.status = dal.GetProjectAllocationStatus();
                    return View();
                }

                else
                {
                    Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                    ViewBag.dept = dal.GetEmployeeDept();
                    ViewBag.workingstatus = dal.GetEmployeeWorkingStatus();
                    ViewBag.status = dal.GetProjectAllocationStatus();
                    return View();
                }
            }
            catch (Exception e)
            {

                return View(e);
            }

            
            
        }

        public ActionResult AddSkillSet()
        {
            Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
            ViewBag.skillname = dal.GetSkillName();
            ViewBag.employeeid = dal.GetEmployeeID();
            return View();
        }
        [HttpPost]

        public ActionResult AddSkillSet(SkillSetModel model)
        {
            try
            {
                if (ModelState.IsValid)
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                int id = dal.AddSkillSet(model);
                ViewBag.msg = "Skill Set Added : " + id;
                ModelState.Clear();
                ViewBag.skillname = dal.GetSkillName();
                ViewBag.employeeid = dal.GetEmployeeID();
                return View();
            }
            else
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                ViewBag.skillname = dal.GetSkillName();
                return View();
            }
            }
            catch (Exception e)
            {

                return View(e);
            }
        }
        public ActionResult AddProject()
        {
            Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
            ViewBag.technology = dal.GetProjectTechnology();
            ViewBag.projectstatus = dal.GetProjectStatus();
            return View();
        }
        [HttpPost]
        public ActionResult AddProject(ProjectModel model)
        {
            try
            {
                if (ModelState.IsValid)
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                int id = dal.AddProject(model);
                ViewBag.msg = "Project Added : " + id;
                ModelState.Clear();
                ViewBag.technology = dal.GetProjectTechnology();
                ViewBag.projectstatus = dal.GetProjectStatus();
                return View();
            }
            else
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                ViewBag.technology = dal.GetProjectTechnology();
                ViewBag.projectstatus = dal.GetProjectStatus();
                return View();
            }
            }
            catch (Exception e)
            {

                return View(e);
            }
        }
        public ActionResult AddProjectAllocation()
        {
            Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
            ViewBag.status = dal.GetProjectAllocationStatus();
            ViewBag.projectid = dal.GetProjectID();
            ViewBag.employeeid = dal.GetEmployeeID();
            return View();
        }
        [HttpPost]
        public ActionResult AddProjectAllocation(ProjectAllocationModel model)
        {
            try
            {

                if (ModelState.IsValid)
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                dal.AddProjectAllocation(model);
                ViewBag.msg = "Project allocation Added";
                ModelState.Clear();
                ViewBag.status = dal.GetProjectAllocationStatus();
                ViewBag.projectid = dal.GetProjectID();
                ViewBag.employeeid = dal.GetEmployeeID();
                return View();
            }
            else
            {
                Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
                ViewBag.status = dal.GetProjectAllocationStatus();
                ViewBag.projectid = dal.GetProjectID();
                ViewBag.employeeid = dal.GetEmployeeID();
                return View();
            }
            }
            catch (Exception e)
            {

                return View(e);
            }
        }

        public ActionResult Search()
        {
            List<EmployeeModel> list = new List<EmployeeModel>();
            return View(list);
        }

        [HttpPost]
        public ActionResult Search(int ManagerID)
        {
            Employee_SkillSet_Project_ProjectAllocation_DAL dal = new Employee_SkillSet_Project_ProjectAllocation_DAL();
            List<EmployeeModel> list = dal.Search(ManagerID);
            return View(list);
        }
    }
}