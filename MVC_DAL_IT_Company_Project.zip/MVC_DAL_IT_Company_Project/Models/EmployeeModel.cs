﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_IT_Company_Project.Models
{
    public class EmployeeModel
    {
        [Display(Name = "Employee ID")]
        public int EmployeeID { get; set; }
        [Display(Name = "Employee First Name")]
        [Required(ErrorMessage = "*")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Too Short Name")]
        public string EmployeeFirstName { get; set; }
        [Display(Name = "Employee Last Name")]
        [Required(ErrorMessage = "*")]
        [StringLength(100, MinimumLength = 5, ErrorMessage = "Too Short Name")]
        public string EmployeeLastName { get; set; }
        [Display(Name = "Employee DOJ")]
        [Required(ErrorMessage = "*")]
        public DateTime EmployeeDOJ { get; set; }
        [Display(Name = "Employee DOB")]
        [Required(ErrorMessage = "*")]
        public DateTime EmployeeDOB { get; set; }
        [Display(Name = "Employee Gender")]
        [Required(ErrorMessage = "*")]
        public string EmployeeGender { get; set; }
        [Display(Name = "Employee Salary")]
        [Required(ErrorMessage = "*")]
        public int EmployeeSalary { get; set; }
        [Display(Name = "Employee Department")]
        [Required(ErrorMessage = "*")]
        public string EmployeeDept { get; set; }

        public string EmployeeImage { get; set; }
        [Display(Name = "Employee Working Status")]
        [Required(ErrorMessage = "*")]
        public string EmployeeWorkingStatus { get; set; }
        [Display(Name = "Employee Experience")]
        [Required(ErrorMessage = "*")]
        public int EmployeeExp { get; set; }
        [Display(Name = "Employee Project Allocation Status")]
        [Required(ErrorMessage = "*")]
        public string EmployeeProjectAllocationStatus { get; set; }
        [Display(Name = "Employee Image File")]
        [Required(ErrorMessage = "*")]
        public HttpPostedFileBase EmployeeImageFile { get; set; }
    }
}