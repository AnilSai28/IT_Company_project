﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_IT_Company_Project.Models
{
    public class ProjectModel
    {
        [Display(Name = "Project ID")]
        public int ProjectID { get; set; }
        [Display(Name = "Project Name")]
        [Required(ErrorMessage = "*")]
        public string ProjectName { get; set; }
        [Display(Name = "Project Technology")]
        [Required(ErrorMessage = "*")]
        public string ProjectTechnology { get; set; }
        [Display(Name = "Project Description")]
        [Required(ErrorMessage = "*")]
        public string ProjectDescription { get; set; }
        [Display(Name = "Project Start Date")]
        [Required(ErrorMessage = "*")]
        public DateTime ProjectStartDate { get; set; }
        [Display(Name = "Project Status")]
        [Required(ErrorMessage = "*")]
        public string ProjectStatus { get; set; }
        [Display(Name = "Manager ID")]
        [Required(ErrorMessage = "*")]
        public int ManagerID { get; set; }
    }
}