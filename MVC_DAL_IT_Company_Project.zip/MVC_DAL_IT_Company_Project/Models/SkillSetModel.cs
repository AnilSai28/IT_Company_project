﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_IT_Company_Project.Models
{
    public class SkillSetModel
    {
        [Display(Name = "Employee ID")]
        [Required(ErrorMessage = "*")]
        public int EmployeeID { get; set; }
        [Display(Name = "Skill Name")]
        [Required(ErrorMessage = "*")]
        public string SkillName { get; set; }
        [Display(Name = "Expertise Level")]
        [Required(ErrorMessage = "*")]
        public int ExpertiseLevel { get; set; }
        [Display(Name = "No Of Employees")]
        [Required(ErrorMessage = "*")]
        public int NoOfEmployees { get; set; }
    }
}