﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using System.Web.Mvc;

namespace MVC_DAL_IT_Company_Project.Models
{
    public class Employee_SkillSet_Project_ProjectAllocation_DAL
    {
        SqlConnection con = new SqlConnection(ConfigurationManager.ConnectionStrings["constr"].ConnectionString);
        public int AddEmployee(EmployeeModel model)
        {
            try
            {
                SqlCommand com_addemployee = new SqlCommand("proc_Employee", con);
                com_addemployee.Parameters.AddWithValue("@EmployeeFirstName", model.EmployeeFirstName);
                com_addemployee.Parameters.AddWithValue("@EmployeeLastName", model.EmployeeLastName);
                com_addemployee.Parameters.AddWithValue("@EmployeeDOJ", model.EmployeeDOJ);
                com_addemployee.Parameters.AddWithValue("@EmployeeDOB", model.EmployeeDOB);
                com_addemployee.Parameters.AddWithValue("@EmployeeGender", model.EmployeeGender);
                com_addemployee.Parameters.AddWithValue("@EmployeeSalary", model.EmployeeSalary);
                com_addemployee.Parameters.AddWithValue("@EmployeeDept", model.EmployeeDept);
                com_addemployee.Parameters.AddWithValue("@EmployeeImage", model.EmployeeImage);
                com_addemployee.Parameters.AddWithValue("@EmployeeWorkingStatus", model.EmployeeWorkingStatus);
                com_addemployee.Parameters.AddWithValue("@EmployeeExp", model.EmployeeExp);
                com_addemployee.Parameters.AddWithValue("@EmployeeProjectAllocationStatus", model.EmployeeProjectAllocationStatus);
                com_addemployee.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addemployee.Parameters.Add(para_ret);
                con.Open();
                com_addemployee.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }
        }
        public List<SelectListItem> GetEmployeeDept()
        {
            List<SelectListItem> dept = new List<SelectListItem>();
            dept.Add(new SelectListItem { Text = "Select", Value = "" });
            dept.Add(new SelectListItem { Text = "HR", Value = "HR" });
            dept.Add(new SelectListItem { Text = "Manager", Value = "Manager" });
            dept.Add(new SelectListItem { Text = "Sub Manager", Value = "Sub Manager" });
            dept.Add(new SelectListItem { Text = "Marketing", Value = "Marketing" });
            dept.Add(new SelectListItem { Text = "Finance", Value = "Finance" });
            dept.Add(new SelectListItem { Text = "Accounting", Value = "Accounting" });
            return dept;
        }
        public List<SelectListItem> GetEmployeeWorkingStatus()
        {
            List<SelectListItem> workingstatus = new List<SelectListItem>();
            workingstatus.Add(new SelectListItem { Text = "Select", Value = "" });
            workingstatus.Add(new SelectListItem { Text = "Employee", Value = "Employee" });
            workingstatus.Add(new SelectListItem { Text = "Contract", Value = "Contract" });
            workingstatus.Add(new SelectListItem { Text = "Resigned", Value = "Resigned" });
            workingstatus.Add(new SelectListItem { Text = "Trainee", Value = "Trainee" });
            return workingstatus;

        }
        public List<SelectListItem> GetProjectAllocationStatus()
        {
            List<SelectListItem> status = new List<SelectListItem>();
            status.Add(new SelectListItem { Text = "Select", Value = "" });
            status.Add(new SelectListItem { Text = "Allocate", Value = "Allocate" });
            status.Add(new SelectListItem { Text = "Dis-Allocate", Value = "Dis-Allocate" });
            return status;
        }
        public List<SelectListItem> GetSkillName()
        {
            List<SelectListItem> skillname = new List<SelectListItem>();
            skillname.Add(new SelectListItem { Text = "Select", Value = "" });
            skillname.Add(new SelectListItem { Text = "C", Value = "C" });
            skillname.Add(new SelectListItem { Text = "C++", Value = "C++" });
            skillname.Add(new SelectListItem { Text = "Java", Value = "Java" });
            skillname.Add(new SelectListItem { Text = "Dotnet", Value = "Dotnet" });
            skillname.Add(new SelectListItem { Text = "Python", Value = "Python" });
            return skillname;
        }
        public List<SelectListItem> GetProjectTechnology()
        {
            List<SelectListItem> technology = new List<SelectListItem>();
            technology.Add(new SelectListItem { Text = "Select", Value = "" });
            technology.Add(new SelectListItem { Text = "Dotnet", Value = "Dotnet" });
            technology.Add(new SelectListItem { Text = "MVC", Value = "MVC" });
            technology.Add(new SelectListItem { Text = "Entity FrameWork", Value = "Entity FrameWork" });
            technology.Add(new SelectListItem { Text = "Web API", Value = "Web API" });
            return technology;
        }
        public List<SelectListItem> GetProjectStatus()
        {
            List<SelectListItem> projectstatus = new List<SelectListItem>();
            projectstatus.Add(new SelectListItem { Text = "Select", Value = "" });
            projectstatus.Add(new SelectListItem { Text = "Completed", Value = "Completed" });
            projectstatus.Add(new SelectListItem { Text = "Pending", Value = "Pending" });
            projectstatus.Add(new SelectListItem { Text = "Working", Value = "Working" });
            return projectstatus;
        }
        public List<SelectListItem> GetProjectID()
        {
            List<SelectListItem> projectid = new List<SelectListItem>();
            projectid.Add(new SelectListItem { Text = "Select", Value = "" });
            projectid.Add(new SelectListItem { Text = "100", Value = "100" });
            projectid.Add(new SelectListItem { Text = "101", Value = "101" });
            projectid.Add(new SelectListItem { Text = "102", Value = "102" });
            projectid.Add(new SelectListItem { Text = "103", Value = "103" });
            projectid.Add(new SelectListItem { Text = "104", Value = "104" });
            projectid.Add(new SelectListItem { Text = "105", Value = "105" });
            return projectid;
        }
        public List<SelectListItem> GetEmployeeID()
        {
            SqlCommand com_employeeid = new SqlCommand("proc_getemployeeinfo", con);
            com_employeeid.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_employeeid.ExecuteReader();
            List<SelectListItem> employeeid = new List<SelectListItem>();
            while(dr.Read())
            {
                employeeid.Add(new SelectListItem { Text = dr.GetInt32(0).ToString(),
                    Value = dr.GetInt32(0).ToString() });
            }
            con.Close();
            return employeeid;
            
        }
        public int AddSkillSet(SkillSetModel model)
        {
            try
            {
                SqlCommand com_addskillset = new SqlCommand("proc_Skillset", con);
                com_addskillset.Parameters.AddWithValue("@EmployeeID", model.EmployeeID);
                com_addskillset.Parameters.AddWithValue("@SkillName", model.SkillName);
                com_addskillset.Parameters.AddWithValue("@SkillExpertiseLevel", model.ExpertiseLevel);
                com_addskillset.Parameters.AddWithValue("@SkillNumberofEmployees", model.NoOfEmployees);
                com_addskillset.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addskillset.Parameters.Add(para_ret);
                con.Open();
                com_addskillset.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }

        }
        public int AddProject(ProjectModel model)
        {
            try
            {
                SqlCommand com_addproject = new SqlCommand("proc_addprojects", con);
                com_addproject.Parameters.AddWithValue("@ProjectName", model.ProjectName);
                com_addproject.Parameters.AddWithValue("@ProjectTechnology", model.ProjectTechnology);
                com_addproject.Parameters.AddWithValue("@ProjectDescription", model.ProjectDescription);
                com_addproject.Parameters.AddWithValue("@ProjectStartDate", model.ProjectStartDate);
                com_addproject.Parameters.AddWithValue("@ProjectStatus", model.ProjectStatus);
                com_addproject.Parameters.AddWithValue("@ProjectManagerID", model.ManagerID);
                com_addproject.CommandType = CommandType.StoredProcedure;
                SqlParameter para_ret = new SqlParameter();
                para_ret.Direction = ParameterDirection.ReturnValue;
                com_addproject.Parameters.Add(para_ret);
                con.Open();
                com_addproject.ExecuteNonQuery();
                con.Close();
                int id = Convert.ToInt32(para_ret.Value);
                return id;
            }
            finally
            {
                con.Close();
            }

        }
        public int AddProjectAllocation(ProjectAllocationModel model)
        {
            SqlCommand com_addprojectallocation = new SqlCommand("proc_addProjectAllocation", con);
            com_addprojectallocation.Parameters.AddWithValue("@ProjectID", model.ProjectID);
            com_addprojectallocation.Parameters.AddWithValue("@EmployeeID", model.EmployeeId);
            com_addprojectallocation.Parameters.AddWithValue("@ProjectAllocationDate", model.ProjectAllocationDate);
            com_addprojectallocation.Parameters.AddWithValue("@ProjectAllocationState", model.ProjectAllocationStatus);
            com_addprojectallocation.CommandType = CommandType.StoredProcedure;
            SqlParameter para_ret = new SqlParameter();
            para_ret.Direction = ParameterDirection.ReturnValue;
            com_addprojectallocation.Parameters.Add(para_ret);
            con.Open();
            com_addprojectallocation.ExecuteNonQuery();
            con.Close();
            int id = Convert.ToInt32(para_ret.Value);
            return id;
        }

        public List<EmployeeModel> Search(int ManagerID)
        {
            SqlCommand com_search = new SqlCommand("proc_search", con);
            com_search.Parameters.AddWithValue("@ManagerID", ManagerID);
            com_search.CommandType = CommandType.StoredProcedure;
            con.Open();
            SqlDataReader dr = com_search.ExecuteReader();
            List<EmployeeModel> list = new List<EmployeeModel>();
            while (dr.Read())
            {
                EmployeeModel model = new EmployeeModel();
                model.EmployeeID = dr.GetInt32(0);
                model.EmployeeFirstName = dr.GetString(1);
                model.EmployeeLastName = dr.GetString(2);
                model.EmployeeDOJ = dr.GetDateTime(3);
                model.EmployeeDOB = dr.GetDateTime(4);
                model.EmployeeGender = dr.GetString(5);
                model.EmployeeSalary = dr.GetInt32(6);
                model.EmployeeDept = dr.GetString(7);
                model.EmployeeImage = dr.GetString(8);
                model.EmployeeWorkingStatus = dr.GetString(9);
                model.EmployeeExp = dr.GetInt32(10);
                model.EmployeeProjectAllocationStatus = dr.GetString(11);
                list.Add(model);
            }
            con.Close();
            return list;
        }

    }
}