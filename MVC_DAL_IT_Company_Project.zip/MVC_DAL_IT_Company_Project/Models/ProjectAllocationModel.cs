﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.ComponentModel.DataAnnotations;

namespace MVC_DAL_IT_Company_Project.Models
{
    public class ProjectAllocationModel
    {
        [Display(Name = "Project ID")]
        [Required(ErrorMessage = "*")]
        public int ProjectID { get; set; }
        [Display(Name = "Employee ID")]
        [Required(ErrorMessage = "*")]
        public int EmployeeId { get; set; }
        [Display(Name = "Project Allocation Date")]
        [Required(ErrorMessage = "*")]
        public DateTime ProjectAllocationDate { get; set; }
        [Display(Name = "Project Allocation Status")]
        [Required(ErrorMessage = "*")]
        public string ProjectAllocationStatus { get; set; }
    }
}