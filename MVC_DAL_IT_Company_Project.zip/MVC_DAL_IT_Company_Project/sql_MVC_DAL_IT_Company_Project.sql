create database IT_Company

use IT_Company

create table tbl_Employee
(
EmployeeID int identity(1000,1) primary key,
EmployeeFirstName varchar(100) not null,
EmployeeLastName varchar(100) not null,
EmployeeDOJ datetime not null,
EmployeeDOB datetime not null,
EmployeeGender varchar(100) not null,
EmployeeSalary int not null,
EmployeeDept varchar(100) not null,
EmployeeImage varchar(100) not null,
EmployeeWorkingStatus varchar(100) not null,
EmployeeExp int not null,
EmployeeProjectAllocationStatus varchar(100) not null
)

create table tbl_Skillset
(
EmployeeID int foreign key references tbl_Employee(EmployeeID),
SkillName varchar(100) not null,
SkillExpertiseLevel int not null,
SkillNumberofEmployees int not null
)

create table tbl_Projects
(
ProjectID int identity(100,1) primary key,
ProjectName varchar(100) not null,
ProjectTechnology varchar(100) not null,
ProjectDescription varchar(100) not null,
ProjectStartDate Datetime not null,
ProjectStatus varchar(100) not null,
ManagerID int foreign key references tbl_Employee(EmployeeID)
)

create table tbl_projectsallocation
(
ProjectID int foreign key references tbl_projects(ProjectID),
EmployeeID int foreign key references tbl_Employee(EmployeeID), 
ProjectAllocationDate datetime not null,
ProjectAllocationStatus varchar(100) not null,
primary key(ProjectID,EmployeeID)
)

--Add Employee

create proc proc_Employee
(@EmployeeFirstName varchar(100),@EmployeeLastName varchar(100),@EmployeeDOJ datetime,
@EmployeeDOB datetime,@EmployeeGender varchar(100),@EmployeeSalary int,@EmployeeDept varchar(100),
@EmployeeImage varchar(100),@EmployeeWorkingStatus  varchar(100),@EmployeeExp int,
@EmployeeProjectAllocationStatus varchar(100))
as
begin
insert tbl_Employee values(@EmployeeFirstName,@EmployeeLastName,@EmployeeDOJ,@EmployeeDOB,
                          @EmployeeGender,@EmployeeSalary,@EmployeeDept,@EmployeeImage,
						  @EmployeeWorkingStatus,@EmployeeExp,@EmployeeProjectAllocationStatus)

return @@identity
end


--Add Skillset

create proc proc_Skillset
(@EmployeeID int,@SkillName varchar(100),@SkillExpertiseLevel int,@SkillNumberofEmployees int)
as
begin
insert tbl_Skillset values(@EmployeeID,@SkillName,@SkillExpertiseLevel,@SkillNumberofEmployees)
return @@rowcount
end

--Add Projects

create proc proc_addprojects
(@ProjectName varchar(100),@ProjectTechnology varchar(100),@ProjectDescription varchar(100) ,
@ProjectStartDate Datetime ,@ProjectStatus varchar(100),@ProjectManagerID int)
as
begin
declare @count int
select @count=count(*) from tbl_Projects where
ManagerID=@ProjectManagerID and ProjectID=@@identity
if(@count=0)
begin
insert tbl_Projects values(@ProjectName,@ProjectTechnology,@ProjectDescription,
                           @ProjectStartDate,@ProjectStatus,@ProjectManagerID)
end
return @@rowcount
end

--AddProjectAllocation

alter proc proc_addProjectAllocation
(@ProjectID int,@EmployeeID int,@ProjectAllocationDate datetime,@ProjectAllocationState varchar(100) )
as
begin
declare @count int
select @count=count(*) from tbl_projectsallocation where
ProjectID=@ProjectID and EmployeeID=@EmployeeID
if(@count=0)
begin
insert tbl_projectsallocation values(@ProjectID,@EmployeeID,@ProjectAllocationDate,@ProjectAllocationState)
end
return @@rowcount
end

exec proc_addProjectAllocation 100,1000,"01/01/2018","allocated"
select * from tbl_Projects
--search
create proc proc_search
(@ManagerID int)
as
begin
select * from tbl_Employee where EmployeeID in(select EmployeeID from tbl_projectsallocation 
where ProjectID in(select ProjectID from tbl_Projects where ManagerID=@ManagerID))
return @@rowcount
end


create proc proc_getemployeeinfo
as
begin
select employeeid,employeefirstname,employeelastname from tbl_Employee
end







